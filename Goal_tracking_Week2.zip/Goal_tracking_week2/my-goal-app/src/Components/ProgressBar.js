import React from "react";
import PropTypes from "prop-types";


function ProgressBar(props){

    const {percentage}=props;

    const outerBarStyle={
   
        background: "rgba(188, 156, 255, 0.25)",
        borderRadius:"2px",
        width:"100%",
        height:"13px",
        display:"flex",
        alignItems:"flex-end",//align the inner bar to the end of the outerbox
    };

    const innerBarStyle={
        background:"linear-gradient(180deg, #BC9CFF 0%, #8BA4F9 100%)",
        opacity:"100 ! important",
        borderRadius:"2px",
        width:percentage+"%",
        height:"100%",

    };

    return (

        <div style={outerBarStyle}>
             <div style={innerBarStyle}>
             </div>
        </div>
    
    );

}
ProgressBar.propTypes = {
   percentage: PropTypes.number.isRequired,
    };
    export default ProgressBar;

