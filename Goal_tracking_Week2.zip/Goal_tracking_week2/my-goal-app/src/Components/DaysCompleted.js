import React from "react";
import PropTypes from "prop-types";


function DaysCompleted(props) {
const { days } = props;


const textStyle={textAlign:"center",color:"#BC9CFF"};

return (
<div>
<h1 style={textStyle}> {days} Days Completed</h1>
</div>
);
}


DaysCompleted.propTypes = {
days: PropTypes.number.isRequired,
};
export default DaysCompleted;